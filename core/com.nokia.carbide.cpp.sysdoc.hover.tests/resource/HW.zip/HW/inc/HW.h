/*
 ============================================================================
 Name		: HW.h
 Author	  : 
 Copyright   : Your copyright notice
 Description : Exe header file
 ============================================================================
 */

#ifndef __HW_H__
#define __HW_H__

//  Include Files

#include <e32base.h>

//  Function Prototypes

GLDEF_C TInt E32Main();

#endif  // __HW_H__


char *version_string = "omni-cpp-1.0";

// distdate.hh -- Automatically generated file

#define OMNIORB_DIST_DATE "Fri Jul 30 11:57:22 BST 2004 dgrisby"


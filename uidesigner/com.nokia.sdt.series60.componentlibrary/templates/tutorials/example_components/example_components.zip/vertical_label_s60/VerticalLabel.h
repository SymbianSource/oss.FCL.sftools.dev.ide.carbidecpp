/*
========================================================================
 Name		: VerticalLabel.h

 Description: 

 Copyright (c) 2006 Nokia Corporation and/or its subsidiary(-ies).
 All rights reserved.
 This component and the accompanying materials are made available
 under the terms of the License "Eclipse Public License v1.0"
 which accompanies this distribution, and is available
 at the URL "http://www.eclipse.org/legal/epl-v10.html".

 Contributors:
 Nokia Corporation - initial contribution.
========================================================================
*/

#ifndef VerticalLabel_H_
#define VerticalLabel_H_

#include <coecntrl.h>

class CVerticalLabel : public CCoeControl
	{
public:

	CVerticalLabel();
	~CVerticalLabel();
	void ConstructFromResourceL(TResourceReader& aReader);
	void Draw(const TRect& aRect) const;
	
protected:
	void SizeChanged();
	
private:
	TInt iLineSize;
	HBufC *iText;
};

#endif /*VerticalLabel_H_*/

/*
 * Copyright (c) 2006 Nokia Corporation and/or its subsidiary(-ies).
 * All rights reserved.
 * This component and the accompanying materials are made available
 * under the terms of the License "Eclipse Public License v1.0"
 * which accompanies this distribution, and is available
 * at the URL "http://www.eclipse.org/legal/epl-v10.html".
 *
 * Initial Contributors:
 * Nokia Corporation - initial contribution.
 *
 * Contributors:
 *
 * Description: 
 *
 */

function getLayoutChildren(children) {
	var result = [];
	var idx = 0;
	if (children != null) {
		for (var i in children) {
			var child = children[i];
			if (child.component != null && child.component.attributes != null 
				&& child.component.attributes["is-non-layout-object"] != "true"
				&& child.component.attributes["is-non-transient-object"] != "true") {
				result[idx++] = child;
			}
		}
	}
	return result;
}
